Ripley brand assets
===================

ripley-bot-avatar.png        1024 x 1024   Developer Portal -> General Information -> App Icon
ripley-bot-banner.png        1360 x 480    Developer Portal -> General Information -> App Banner (2x)
ripley-bot-banner-680x240.png  680 x 240   same banner at Discord's minimum size
ripley-mark.svg              vector        the mark on its own, white on dark
ripley-wordmark.png          transparent   mark + wordmark lockup

Colors
  Background      #0A0A0A
  Mark and text   #FFFFFF
  Discord blurple #5865F2
  Money green     #22C55E

Type
  Display  Space Grotesk
  Body     DM Sans

Clear space: keep at least one bar-height of empty space around the mark.
These are Ripley's own assets. Ripley is not affiliated with Discord Inc.
